/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package carrentalservice_questiontwo;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 *
 * @author sabas
 */
public class CarTest {
    
    private Car car;

    @Before
    public void setUp() {
        car = new Car("Toyota", "Camry", 2022);
    }

    @Test
    public void testConstructor() {
        assertEquals("Toyota", car.getMake());
        assertEquals("Camry", car.getModel());
        assertEquals(2022, car.getYear());
        assertTrue(car.isAvailable());
    }

    @Test
    public void testRentCar() {
        car.rent();
        assertFalse(car.isAvailable());
    }

    @Test
    public void testReturnCar() {
        car.rent();
        car.returnCar();
        assertTrue(car.isAvailable());
    }
}


