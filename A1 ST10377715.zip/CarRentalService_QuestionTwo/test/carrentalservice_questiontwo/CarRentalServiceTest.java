/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package carrentalservice_questiontwo;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 *
 * @author sabas
 */
public class CarRentalServiceTest {
    
    private CarRentalService carRentalService;

    @Before
    public void setUp() {
        carRentalService = new CarRentalService(3);
    }

    @Test
    public void testAddCar() {
        Car car = new Car("Toyota", "Camry", 2022);
        carRentalService.addCar(car);
        assertTrue(car.isAvailable());
    }

    @Test
    public void testRentCar() {
        Car car = new Car("Toyota", "Camry", 2022);
        carRentalService.addCar(car);

        carRentalService.rentCar("Toyota", "Camry");
        assertFalse(car.isAvailable());
    }

    @Test
    public void testReturnCar() {
        Car car = new Car("Toyota", "Camry", 2022);
        carRentalService.addCar(car);

        carRentalService.rentCar("Toyota", "Camry");
        carRentalService.returnCar("Toyota", "Camry");
        assertTrue(car.isAvailable());
    }
}

