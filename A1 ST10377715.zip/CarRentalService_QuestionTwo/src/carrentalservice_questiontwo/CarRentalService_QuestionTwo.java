/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carrentalservice_questiontwo;

import java.util.Scanner;

/**
 *
 * @author sabas
 */
public class CarRentalService_QuestionTwo 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        CarRentalService carRentalService = new CarRentalService(10);

        // Add some initial cars to the rental service
        Car car1 = new Car("Toyota", "Camry", 2022);
        Car car2 = new Car("Honda", "Civic", 2023);

        carRentalService.addCar(car1);
        carRentalService.addCar(car2);

        while (true) {
            displayMenu();

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter the make of the car you want to rent: ");
                    String makeToRent = scanner.nextLine();
                    System.out.print("Enter the model of the car you want to rent: ");
                    String modelToRent = scanner.nextLine();

                    carRentalService.rentCar(makeToRent, modelToRent);
                    break;
                case 2:
                    System.out.print("Enter the make of the car you want to return: ");
                    String makeToReturn = scanner.nextLine();
                    System.out.print("Enter the model of the car you want to return: ");
                    String modelToReturn = scanner.nextLine();

                    carRentalService.returnCar(makeToReturn, modelToReturn);
                    break;
                case 3:
                    carRentalService.displayRentalServiceStatus();
                    break;
                case 4:
                    System.out.println("Exiting the application. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. Rent a car");
        System.out.println("2. Return a car");
        System.out.println("3. Display rental service status");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }
}
    
   
    

