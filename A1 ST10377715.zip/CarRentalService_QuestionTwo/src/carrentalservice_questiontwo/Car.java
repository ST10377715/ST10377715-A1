/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carrentalservice_questiontwo;

/**
 *
 * @author sabas
 */
public class Car {
    private String make;
    private String model;
    private int year;
    private boolean available;

    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.available = true;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public boolean isAvailable() {
        return available;
    }

    public void rent() {
        if (available) {
            available = false;
        } else {
            System.out.println("This car is already rented.");
        }
    }

    public void returnCar() {
        if (!available) {
            available = true;
        } else {
            System.out.println("This car is already available for rent.");
        }
    }
}

