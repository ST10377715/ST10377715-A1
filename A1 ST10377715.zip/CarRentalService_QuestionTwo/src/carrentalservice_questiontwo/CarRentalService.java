/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carrentalservice_questiontwo;

/**
 *
 * @author sabas
 */
public class CarRentalService 
{
    private Car[] cars;

    public CarRentalService(int capacity) {
        cars = new Car[capacity];
    }

    public void addCar(Car car) {
        for (int i = 0; i < cars.length; i++) {
            if (cars[i] == null) {
                cars[i] = car;
                System.out.println("Car added to the rental service: " + car.getMake() + " " + car.getModel());
                return;
            }
        }
        System.out.println("The rental service is full. Cannot add more cars.");
    }

    public void rentCar(String make, String model) {
        for (Car car : cars) {
            if (car != null && car.getMake().equalsIgnoreCase(make) && car.getModel().equalsIgnoreCase(model) && car.isAvailable()) {
                car.rent();
                System.out.println("Car rented: " + car.getMake() + " " + car.getModel());
                return;
            }
        }
        System.out.println("Car not found or already rented.");
    }

    public void returnCar(String make, String model) {
        for (Car car : cars) {
            if (car != null && car.getMake().equalsIgnoreCase(make) && car.getModel().equalsIgnoreCase(model) && !car.isAvailable()) {
                car.returnCar();
                System.out.println("Car returned: " + car.getMake() + " " + car.getModel());
                return;
            }
        }
        System.out.println("Car not found or already available for rent.");
    }

    public void displayRentalServiceStatus() {
        System.out.println("Rental Service Status:");
        for (Car car : cars) {
            if (car != null) {
                System.out.println("Make: " + car.getMake());
                System.out.println("Model: " + car.getModel());
                System.out.println("Year: " + car.getYear());
                System.out.println("Availability: " + (car.isAvailable() ? "Available" : "Not Available"));
                System.out.println("---------------------------");
            }
        }
    }
}
    
