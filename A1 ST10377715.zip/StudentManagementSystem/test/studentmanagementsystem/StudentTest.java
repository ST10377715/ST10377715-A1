/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentmanagementsystem;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author sabas
 */
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class StudentTest {
    private Student studentManager;

    @Before
    public void setUp() {
     
    }

    @Test
    public void testCaptureStudent() {
        // Capture a new student
        studentManager.captureStudent("12345", "John Doe", 20);

        // Retrieve the saved student and check if details match
        Student  student = new Student("","",0);
        Student savedStudent = student.searchStudent("12345");
        assertNotNull(savedStudent);
        assertEquals("12345", savedStudent.getId());
        assertEquals("John Doe", savedStudent.getName());
        assertEquals(20, savedStudent.getAge());
    }

    @Test
    public void testSearchStudent() {
        // Capture a new student
        studentManager.captureStudent("12345", "John Doe", 20);

        // Search for the saved student by ID
        Student foundStudent = studentManager.searchStudent("12345");

        assertNotNull(foundStudent);
        assertEquals("12345", foundStudent.getId());
        assertEquals("John Doe", foundStudent.getName());
        assertEquals(20, foundStudent.getAge());
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        // Search for a non-existent student by ID
        Student student = new Student("","",0);
        Student foundStudent = student.searchStudent("99999");
    

        assertNull(foundStudent);
    }

    @Test
    public void testDeleteStudent() {
        // Capture a new student
        Student student = new Student("","",0);
        student.captureStudent("12345", "John Doe", 20);

        // Delete the saved student by ID
        boolean deleted = student.deleteStudent("12345");

        assertTrue(deleted);

        // Verify that the student has been deleted
        Student deletedStudent = studentManager.searchStudent("12345");
        assertNull(deletedStudent);
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Delete a non-existent student by ID
        boolean deleted = studentManager.deleteStudent("99999");

        assertFalse(deleted);
    }

 


    

