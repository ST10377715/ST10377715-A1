/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementsystem;

/**
 *
 * @author sabas
 */
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class StudentManagementSystem {
 
    private ArrayList<Student> studentList = new ArrayList<>();
     final static Scanner scanner = new Scanner(System.in);
    
        public static void main(String[] args) {
        Student studentApp = new Student("", "", 0);

        while (true) {
            studentApp. displayMenu();
            int choice;
            choice = studentApp.getUserChoice();

            switch (choice) {
                case 1:
                    studentApp.captureStudent();
                    break;
                case 2:
                    studentApp.searchStudent();
                    break;
                case 3:
                    studentApp.deleteStudent();
                    break;
                case 4:
                    studentApp.studentReport();
                    break;
                case 5:
                    studentApp.exitStudentApplication();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
}
  
}




 


