/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import static studentmanagementsystem.StudentManagementSystem.scanner;

/**
 *
 * @author sabas
 */
public class Student {
    private String name;
    private int age;
    private String id;

    public Student(String id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
    
     private ArrayList<Student> studentList = new ArrayList<>();
     final static Scanner scanner = new Scanner(System.in);
    
          public void captureStudent(String id, String name, int age) {
    System.out.print("Enter student ID: ");
    id = scanner.next();
    System.out.print("Enter student name: ");
    name = scanner.next();
    while (true) {
        try {
            System.out.print("Enter student age: ");
            age = scanner.nextInt();
            if (age >= 16) {
                break;
            } else {
                System.out.println("Invalid age. Age must be greater than or equal to 16.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number for age.");
            scanner.next(); // Consume the invalid input
        }
    }

    Student student = new Student(id, name, age);
    studentList.add(student);
    System.out.println("Student details saved successfully.");
}

    

   public void searchStudent(String searchId) {
    System.out.print("Enter student ID to search: ");
    searchId = scanner.next();
    boolean found = false;

    for (Student student : studentList) {
        if (student.getId().equals(searchId)) {
            System.out.println("Student found:");
            System.out.println("ID: " + student.getId());
            System.out.println("Name: " + student.getName());
            System.out.println("Age: " + student.getAge());
            found = true;
            break;
        }
    }

    if (!found) {
        System.out.println("Student not found.");
    }
}


public void deleteStudent(String deleteId) {
    System.out.print("Enter student ID to delete: ");
    deleteId = scanner.next();
    boolean found = false;

    for (Student student : studentList) {
        if (student.getId().equals(deleteId)) {
            studentList.remove(student);
            System.out.println("Student with ID " + deleteId + " has been deleted.");
            found = true;
            break;
        }
    }

    if (!found) {
        System.out.println("Student with ID " + deleteId + " not found. No changes made.");
    }
}

public void studentReport() {
    if (studentList.isEmpty()) {
        System.out.println("No students to generate a report for.");
    } else {
        System.out.println("Student Report:");
        for (Student student : studentList) {
            System.out.println("ID: " + student.getId());
            System.out.println("Name: " + student.getName());
            System.out.println("Age: " + student.getAge());
            System.out.println("---------------------------");
        }
    }
   
    
}

    public void exitStudentApplication() {
        System.out.println("Exiting the application. Goodbye!");
        System.exit(0);
    }
     public static void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. Capture a new student");
        System.out.println("2. Search for a student");
        System.out.println("3. Delete a student");
        System.out.println("4. View student report");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
    }

    public static int getUserChoice() {
        int choice;
        while (true) {
            try {
                choice = scanner.nextInt();
                break;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next(); // Consume the invalid input
            }
        }
        return choice;
    }
}

